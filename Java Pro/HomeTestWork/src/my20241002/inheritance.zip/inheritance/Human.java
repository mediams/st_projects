package my20241002.inheritance;

public class Human extends Creature {

    private String name;

    public Human(String name) {
        this.name = name;
    }

    public void feedAnimal(Animal animal) {
        animal.setHungry(false);
        System.out.println("Animal " + animal.getName() + " is not hungry anymore");
    }

    public void walkAnimal (Animal animal){
        animal.setHungry(true);
        System.out.println("The animal has taken a walk and is hungry.");
    }

    public void walkAnimal (Animal... animal){
        for (Animal a : animal){
            walkAnimal(a);
        }
    }

    public void feedAnimals(Animal... animals) {
        for (Animal a : animals) {
            feedAnimal(a);
        }
    }


    @Override
    public void introduce() {
        System.out.printf("Hi! I'm %s. I'm the man who owns this whole zoo.\n", name);
    }

    @Override
    public void play(Creature another) {
//        System.out.println(getClass().getSimpleName() + " play with " + another.getClass().getSimpleName());
        System.out.println(this.name + another.name);
    }
}

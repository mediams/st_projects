package my20241002.inheritance;

public interface CatchingSkills {
    public void catchMouse();
}

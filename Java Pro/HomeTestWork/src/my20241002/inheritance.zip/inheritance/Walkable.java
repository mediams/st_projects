package my20241002.inheritance;

public interface Walkable {
    public void walk(Animal animal);
}

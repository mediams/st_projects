public abstract class Character {
    private String name;
    private int health = 100;

    public Character(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public int getHealth() {
        return health;
    }

    public abstract int countForce();

    public abstract int countProtection();

    public int fight(Character another) {

        if (another.countForce() > this.countForce()) {
            System.out.println(another.getName() + " WIN!!");
            health = health - (another.countForce() - this.countForce()) / this.countProtection();
            return health;
        } else if (this.countForce() > another.countForce()) {
            System.out.println(this.getName() + " WIN!!");
            health = health - (this.countForce() - another.countForce()) / another.countProtection();
            return health;

        }else {
            System.out.println("Drow!");
            return health;
        }


    }

    public void introduce() {
        System.out.printf("Hi! My name is %s, I have %d Health.\n", name, health);
    }


}
